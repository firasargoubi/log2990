import { Component, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'app-create-game-card',
    templateUrl: './create-game-card.component.html',
    styleUrls: ['./create-game-card.component.scss'],
})
export class CreateGameCardComponent {
    @Output() createGame = new EventEmitter<void>();
    onCreateClick(): void {
        this.createGame.emit();
    }
}